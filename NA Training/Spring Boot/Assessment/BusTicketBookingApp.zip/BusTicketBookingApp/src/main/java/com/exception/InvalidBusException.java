package com.exception;

public class InvalidBusException extends Exception{
	public InvalidBusException(String msg) {
		super(msg);
	}
}